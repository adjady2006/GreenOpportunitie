using GreenOpportunities.API.DTOs;
using GreenOpportunities.API.Helpers;
using GreenOpportunities.API.Models;
using GreenOpportunities.API.Repositories;

namespace GreenOpportunities.API.Services;

/// <summary>
/// Implémentation du service d'authentification.
/// Utilise BCrypt pour le hashage des mots de passe et JWT pour l'émission des tokens.
/// </summary>
public class AuthService : IAuthService
{
    private readonly IUserRepository _userRepository;
    private readonly JwtTokenGenerator _tokenGenerator;

    public AuthService(IUserRepository userRepository, JwtTokenGenerator tokenGenerator)
    {
        _userRepository = userRepository;
        _tokenGenerator = tokenGenerator;
    }

    public async Task<AuthResponseDto?> RegisterAsync(RegisterDto dto, CancellationToken cancellationToken = default)
    {
        if (await _userRepository.ExistsAsync(dto.Username, dto.Email, cancellationToken))
        {
            return null; // conflit username/email
        }

        var user = new ApplicationUser
        {
            Username = dto.Username.Trim(),
            Email = dto.Email.Trim().ToLowerInvariant(),
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
            Role = "Admin",
        };

        var created = await _userRepository.CreateAsync(user, cancellationToken);
        var (token, expiresAt) = _tokenGenerator.GenerateToken(created);

        return new AuthResponseDto
        {
            Token = token,
            Username = created.Username,
            Email = created.Email,
            Role = created.Role,
            ExpiresAt = expiresAt,
        };
    }

    public async Task<AuthResponseDto?> LoginAsync(LoginDto dto, CancellationToken cancellationToken = default)
    {
        var user = await _userRepository.GetByUsernameAsync(dto.Username, cancellationToken);
        if (user is null)
        {
            return null;
        }

        if (!BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
        {
            return null;
        }

        var (token, expiresAt) = _tokenGenerator.GenerateToken(user);
        return new AuthResponseDto
        {
            Token = token,
            Username = user.Username,
            Email = user.Email,
            Role = user.Role,
            ExpiresAt = expiresAt,
        };
    }
}