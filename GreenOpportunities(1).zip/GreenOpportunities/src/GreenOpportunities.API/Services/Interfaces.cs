using GreenOpportunities.API.DTOs;

namespace GreenOpportunities.API.Services;

/// <summary>
/// Interface du service métier pour les opportunités.
/// </summary>
public interface IOpportunityService
{
    Task<PagedResultDto<OpportunityResponseDto>> SearchAsync(OpportunityQueryParameters parameters, CancellationToken cancellationToken = default);
    Task<OpportunityResponseDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<OpportunityResponseDto> CreateAsync(CreateOpportunityDto dto, CancellationToken cancellationToken = default);
    Task<OpportunityResponseDto?> UpdateAsync(int id, UpdateOpportunityDto dto, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default);
}

/// <summary>
/// Interface du service d'authentification.
/// </summary>
public interface IAuthService
{
    Task<AuthResponseDto?> RegisterAsync(RegisterDto dto, CancellationToken cancellationToken = default);
    Task<AuthResponseDto?> LoginAsync(LoginDto dto, CancellationToken cancellationToken = default);
}