using GreenOpportunities.API.DTOs;
using GreenOpportunities.API.Models;
using GreenOpportunities.API.Repositories;

namespace GreenOpportunities.API.Services;

/// <summary>
/// Implémentation du service métier Opportunity.
/// Contient la validation et la transformation entre DTOs et entités.
/// </summary>
public class OpportunityService : IOpportunityService
{
    private readonly IOpportunityRepository _repository;

    public OpportunityService(IOpportunityRepository repository)
    {
        _repository = repository;
    }

    public async Task<PagedResultDto<OpportunityResponseDto>> SearchAsync(
        OpportunityQueryParameters parameters,
        CancellationToken cancellationToken = default)
    {
        var page = await _repository.SearchAsync(parameters, cancellationToken);
        return new PagedResultDto<OpportunityResponseDto>
        {
            Page = page.Page,
            PageSize = page.PageSize,
            TotalItems = page.TotalItems,
            Items = page.Items.Select(OpportunityResponseDto.FromEntity).ToList(),
        };
    }

    public async Task<OpportunityResponseDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await _repository.GetByIdAsync(id, cancellationToken);
        return entity is null ? null : OpportunityResponseDto.FromEntity(entity);
    }

    public async Task<OpportunityResponseDto> CreateAsync(CreateOpportunityDto dto, CancellationToken cancellationToken = default)
    {
        var entity = new Opportunity
        {
            Title = dto.Title.Trim(),
            Description = dto.Description.Trim(),
            Type = dto.Type.Trim(),
            Country = dto.Country.Trim(),
            Deadline = dto.Deadline,
            IsFullyFunded = dto.IsFullyFunded,
        };

        var created = await _repository.CreateAsync(entity, cancellationToken);
        return OpportunityResponseDto.FromEntity(created);
    }

    public async Task<OpportunityResponseDto?> UpdateAsync(int id, UpdateOpportunityDto dto, CancellationToken cancellationToken = default)
    {
        if (!await _repository.ExistsAsync(id, cancellationToken))
        {
            return null;
        }

        var entity = new Opportunity
        {
            Id = id,
            Title = dto.Title.Trim(),
            Description = dto.Description.Trim(),
            Type = dto.Type.Trim(),
            Country = dto.Country.Trim(),
            Deadline = dto.Deadline,
            IsFullyFunded = dto.IsFullyFunded,
        };

        var updated = await _repository.UpdateAsync(entity, cancellationToken);
        return updated is null ? null : OpportunityResponseDto.FromEntity(updated);
    }

    public Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        return _repository.DeleteAsync(id, cancellationToken);
    }
}