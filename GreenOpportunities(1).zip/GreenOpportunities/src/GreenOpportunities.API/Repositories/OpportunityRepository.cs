using GreenOpportunities.API.Data;
using GreenOpportunities.API.DTOs;
using GreenOpportunities.API.Models;
using Microsoft.EntityFrameworkCore;

namespace GreenOpportunities.API.Repositories;

/// <summary>
/// Implémentation EF Core du repository Opportunity.
/// </summary>
public class OpportunityRepository : IOpportunityRepository
{
    private readonly AppDbContext _context;

    public OpportunityRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<PagedResultDto<Opportunity>> SearchAsync(
        OpportunityQueryParameters parameters,
        CancellationToken cancellationToken = default)
    {
        var query = _context.Opportunities.AsQueryable();

        // Recherche par mot-clé dans titre / description (insensible à la casse)
        if (!string.IsNullOrWhiteSpace(parameters.Keyword))
        {
            var keyword = parameters.Keyword.Trim().ToLower();
            query = query.Where(o =>
                o.Title.ToLower().Contains(keyword) ||
                o.Description.ToLower().Contains(keyword));
        }

        // Filtre par type
        if (!string.IsNullOrWhiteSpace(parameters.Type))
        {
            var type = parameters.Type.Trim();
            query = query.Where(o => o.Type == type);
        }

        // Filtre par pays (contient, insensible à la casse)
        if (!string.IsNullOrWhiteSpace(parameters.Country))
        {
            var country = parameters.Country.Trim().ToLower();
            query = query.Where(o => o.Country.ToLower().Contains(country));
        }

        // Filtre financement complet
        if (parameters.IsFullyFunded.HasValue)
        {
            query = query.Where(o => o.IsFullyFunded == parameters.IsFullyFunded.Value);
        }

        var totalItems = await query.CountAsync(cancellationToken);

        var items = await query
            .OrderByDescending(o => o.CreatedAt)
            .Skip((parameters.Page - 1) * parameters.PageSize)
            .Take(parameters.PageSize)
            .ToListAsync(cancellationToken);

        return new PagedResultDto<Opportunity>
        {
            Page = parameters.Page,
            PageSize = parameters.PageSize,
            TotalItems = totalItems,
            Items = items,
        };
    }

    public async Task<Opportunity?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Opportunities
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.Id == id, cancellationToken);
    }

    public async Task<Opportunity> CreateAsync(Opportunity opportunity, CancellationToken cancellationToken = default)
    {
        opportunity.CreatedAt = DateTime.UtcNow;
        _context.Opportunities.Add(opportunity);
        await _context.SaveChangesAsync(cancellationToken);
        return opportunity;
    }

    public async Task<Opportunity?> UpdateAsync(Opportunity opportunity, CancellationToken cancellationToken = default)
    {
        var existing = await _context.Opportunities.FirstOrDefaultAsync(o => o.Id == opportunity.Id, cancellationToken);
        if (existing is null)
        {
            return null;
        }

        existing.Title = opportunity.Title;
        existing.Description = opportunity.Description;
        existing.Type = opportunity.Type;
        existing.Country = opportunity.Country;
        existing.Deadline = opportunity.Deadline;
        existing.IsFullyFunded = opportunity.IsFullyFunded;

        await _context.SaveChangesAsync(cancellationToken);
        return existing;
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var existing = await _context.Opportunities.FirstOrDefaultAsync(o => o.Id == id, cancellationToken);
        if (existing is null)
        {
            return false;
        }

        _context.Opportunities.Remove(existing);
        await _context.SaveChangesAsync(cancellationToken);
        return true;
    }

    public async Task<bool> ExistsAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Opportunities.AnyAsync(o => o.Id == id, cancellationToken);
    }
}