using GreenOpportunities.API.DTOs;
using GreenOpportunities.API.Models;

namespace GreenOpportunities.API.Repositories;

/// <summary>
/// Interface du repository des opportunités. Permet de découpler l'accès aux données
/// de la couche Service.
/// </summary>
public interface IOpportunityRepository
{
    Task<PagedResultDto<Opportunity>> SearchAsync(OpportunityQueryParameters parameters, CancellationToken cancellationToken = default);
    Task<Opportunity?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<Opportunity> CreateAsync(Opportunity opportunity, CancellationToken cancellationToken = default);
    Task<Opportunity?> UpdateAsync(Opportunity opportunity, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default);
    Task<bool> ExistsAsync(int id, CancellationToken cancellationToken = default);
}

/// <summary>
/// Interface du repository des utilisateurs.
/// </summary>
public interface IUserRepository
{
    Task<ApplicationUser?> GetByUsernameAsync(string username, CancellationToken cancellationToken = default);
    Task<ApplicationUser?> GetByEmailAsync(string email, CancellationToken cancellationToken = default);
    Task<ApplicationUser> CreateAsync(ApplicationUser user, CancellationToken cancellationToken = default);
    Task<bool> ExistsAsync(string username, string email, CancellationToken cancellationToken = default);
}