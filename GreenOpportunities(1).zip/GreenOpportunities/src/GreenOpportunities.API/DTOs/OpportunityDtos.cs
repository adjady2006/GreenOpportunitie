using System.ComponentModel.DataAnnotations;
using GreenOpportunities.API.Models;

namespace GreenOpportunities.API.DTOs;

/// <summary>
/// DTO utilisé pour la création d'une opportunité (POST).
/// </summary>
public class CreateOpportunityDto
{
    [Required(ErrorMessage = "Le titre est obligatoire.")]
    [StringLength(200, MinimumLength = 3)]
    public string Title { get; set; } = string.Empty;

    [Required(ErrorMessage = "La description est obligatoire.")]
    [StringLength(4000)]
    public string Description { get; set; } = string.Empty;

    [Required(ErrorMessage = "Le type est obligatoire.")]
    [StringLength(50)]
    public string Type { get; set; } = string.Empty;

    [Required(ErrorMessage = "Le pays est obligatoire.")]
    [StringLength(200)]
    public string Country { get; set; } = string.Empty;

    [Required(ErrorMessage = "La date limite est obligatoire.")]
    public DateTime Deadline { get; set; }

    public bool IsFullyFunded { get; set; }
}

/// <summary>
/// DTO utilisé pour la modification complète d'une opportunité (PUT).
/// </summary>
public class UpdateOpportunityDto
{
    [Required]
    [StringLength(200, MinimumLength = 3)]
    public string Title { get; set; } = string.Empty;

    [Required]
    [StringLength(4000)]
    public string Description { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string Type { get; set; } = string.Empty;

    [Required]
    [StringLength(200)]
    public string Country { get; set; } = string.Empty;

    [Required]
    public DateTime Deadline { get; set; }

    public bool IsFullyFunded { get; set; }
}

/// <summary>
/// DTO renvoyé au client pour exposer une opportunité.
/// </summary>
public class OpportunityResponseDto
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public DateTime Deadline { get; set; }
    public bool IsFullyFunded { get; set; }
    public DateTime CreatedAt { get; set; }

    public static OpportunityResponseDto FromEntity(Opportunity entity) => new()
    {
        Id = entity.Id,
        Title = entity.Title,
        Description = entity.Description,
        Type = entity.Type,
        Country = entity.Country,
        Deadline = entity.Deadline,
        IsFullyFunded = entity.IsFullyFunded,
        CreatedAt = entity.CreatedAt,
    };
}

/// <summary>
/// Réponse paginée standard pour la liste des opportunités.
/// </summary>
public class PagedResultDto<T>
{
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalItems { get; set; }
    public int TotalPages => (int)Math.Ceiling((double)TotalItems / PageSize);
    public IEnumerable<T> Items { get; set; } = Array.Empty<T>();
}

/// <summary>
/// Paramètres de requête pour la recherche / pagination / filtrage.
/// </summary>
public class OpportunityQueryParameters
{
    private const int MaxPageSize = 100;
    private int _pageSize = 10;

    public int Page { get; set; } = 1;

    public int PageSize
    {
        get => _pageSize;
        set => _pageSize = value > MaxPageSize ? MaxPageSize : (value < 1 ? 1 : value);
    }

    /// <summary>Mot-clé à rechercher dans Title ou Description.</summary>
    public string? Keyword { get; set; }

    /// <summary>Filtre par type (ex: Scholarship, Training...).</summary>
    public string? Type { get; set; }

    /// <summary>Filtre par pays (ex: Morocco, Germany...).</summary>
    public string? Country { get; set; }

    /// <summary>Filtre "entièrement financée".</summary>
    public bool? IsFullyFunded { get; set; }
}