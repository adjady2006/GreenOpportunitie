using System.ComponentModel.DataAnnotations;

namespace GreenOpportunities.API.Models;

/// <summary>
/// Représente une opportunité (bourse, formation, concours, etc.) publiée sur la plateforme "فرص خضراء".
/// </summary>
public class Opportunity
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Le titre est obligatoire.")]
    [StringLength(200, MinimumLength = 3)]
    public string Title { get; set; } = string.Empty;

    [Required(ErrorMessage = "La description est obligatoire.")]
    [StringLength(4000)]
    public string Description { get; set; } = string.Empty;

    /// <summary>
    /// Type d'opportunité : Scholarship (منحة), Training (تدريب), Competition (مسابقة), Internship, Fellowship, Grant, Other.
    /// </summary>
    [Required]
    [StringLength(50)]
    public string Type { get; set; } = string.Empty;

    /// <summary>
    /// Pays où l'opportunité est disponible. Plusieurs pays peuvent être séparés par une virgule.
    /// </summary>
    [Required]
    [StringLength(200)]
    public string Country { get; set; } = string.Empty;

    /// <summary>
    /// Date limite de candidature.
    /// </summary>
    [Required]
    public DateTime Deadline { get; set; }

    /// <summary>
    /// Indique si l'opportunité est entièrement financée.
    /// </summary>
    public bool IsFullyFunded { get; set; }

    /// <summary>
    /// Date d'ajout de l'opportunité dans le système.
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}