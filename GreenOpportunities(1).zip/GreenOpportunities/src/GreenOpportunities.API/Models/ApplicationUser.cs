using System.ComponentModel.DataAnnotations;

namespace GreenOpportunities.API.Models;

/// <summary>
/// Représente un utilisateur (administrateur / éditeur) autorisé à modifier les opportunités.
/// </summary>
public class ApplicationUser
{
    public int Id { get; set; }

    [Required]
    [StringLength(100)]
    public string Username { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;

    /// <summary>
    /// Mot de passe hashé avec BCrypt.
    /// </summary>
    [Required]
    public string PasswordHash { get; set; } = string.Empty;

    /// <summary>
    /// Rôle de l'utilisateur : "Admin" ou "Editor". Par défaut "Admin".
    /// </summary>
    [Required]
    [StringLength(20)]
    public string Role { get; set; } = "Admin";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}