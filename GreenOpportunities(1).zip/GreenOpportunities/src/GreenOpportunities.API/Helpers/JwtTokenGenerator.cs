using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using GreenOpportunities.API.Models;
using Microsoft.IdentityModel.Tokens;

namespace GreenOpportunities.API.Helpers;

/// <summary>
/// Configuration du token JWT (clé, issuer, audience, durée).
/// </summary>
public class JwtSettings
{
    public string Secret { get; set; } = string.Empty;
    public string Issuer { get; set; } = "GreenOpportunitiesAPI";
    public string Audience { get; set; } = "GreenOpportunitiesClient";
    public int ExpirationInMinutes { get; set; } = 60 * 24; // 24h par défaut
}

/// <summary>
/// Génère un JWT signé pour un utilisateur authentifié.
/// </summary>
public class JwtTokenGenerator
{
    private readonly JwtSettings _settings;

    public JwtTokenGenerator(JwtSettings settings)
    {
        _settings = settings;
    }

    public (string token, DateTime expiresAt) GenerateToken(ApplicationUser user)
    {
        var keyBytes = Encoding.UTF8.GetBytes(_settings.Secret);
        var credentials = new SigningCredentials(
            new SymmetricSecurityKey(keyBytes),
            SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.UniqueName, user.Username),
            new Claim(JwtRegisteredClaimNames.Email, user.Email),
            new Claim(ClaimTypes.Role, user.Role),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        };

        var expiresAt = DateTime.UtcNow.AddMinutes(_settings.ExpirationInMinutes);

        var token = new JwtSecurityToken(
            issuer: _settings.Issuer,
            audience: _settings.Audience,
            claims: claims,
            notBefore: DateTime.UtcNow,
            expires: expiresAt,
            signingCredentials: credentials);

        var serialized = new JwtSecurityTokenHandler().WriteToken(token);
        return (serialized, expiresAt);
    }
}