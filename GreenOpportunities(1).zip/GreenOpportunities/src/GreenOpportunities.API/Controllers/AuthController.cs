using GreenOpportunities.API.DTOs;
using GreenOpportunities.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace GreenOpportunities.API.Controllers;

/// <summary>
/// Endpoints d'inscription et de connexion. Renvoie un JWT en cas de succès.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;

    public AuthController(IAuthService authService)
    {
        _authService = authService;
    }

    /// <summary>
    /// Crée un nouveau compte utilisateur (rôle Admin par défaut).
    /// </summary>
    [HttpPost("register")]
    [ProducesResponseType(typeof(AuthResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<AuthResponseDto>> Register(
        [FromBody] RegisterDto dto,
        CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        var result = await _authService.RegisterAsync(dto, cancellationToken);
        if (result is null)
        {
            return Conflict(new { message = "Nom d'utilisateur ou email déjà utilisé." });
        }
        return StatusCode(StatusCodes.Status201Created, result);
    }

    /// <summary>
    /// Authentifie un utilisateur et renvoie un JWT.
    /// </summary>
    [HttpPost("login")]
    [ProducesResponseType(typeof(AuthResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<AuthResponseDto>> Login(
        [FromBody] LoginDto dto,
        CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        var result = await _authService.LoginAsync(dto, cancellationToken);
        if (result is null)
        {
            return Unauthorized(new { message = "Identifiants invalides." });
        }
        return Ok(result);
    }
}