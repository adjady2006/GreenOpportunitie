using GreenOpportunities.API.DTOs;
using GreenOpportunities.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GreenOpportunities.API.Controllers;

/// <summary>
/// Endpoints CRUD + recherche/filtrage pour les opportunités.
/// - Lecture (GET) : accessible à tous (anonymes).
/// - Écriture (POST/PUT/DELETE) : requiert un JWT valide.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class OpportunitiesController : ControllerBase
{
    private readonly IOpportunityService _service;

    public OpportunitiesController(IOpportunityService service)
    {
        _service = service;
    }

    /// <summary>
    /// Liste paginée des opportunités avec recherche et filtrage.
    /// </summary>
    /// <param name="parameters">Paramètres de pagination et de filtrage.</param>
    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType(typeof(PagedResultDto<OpportunityResponseDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<PagedResultDto<OpportunityResponseDto>>> GetAll(
        [FromQuery] OpportunityQueryParameters parameters,
        CancellationToken cancellationToken)
    {
        var result = await _service.SearchAsync(parameters, cancellationToken);
        return Ok(result);
    }

    /// <summary>
    /// Récupère une opportunité par son identifiant.
    /// </summary>
    [HttpGet("{id:int}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(OpportunityResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<OpportunityResponseDto>> GetById(int id, CancellationToken cancellationToken)
    {
        var entity = await _service.GetByIdAsync(id, cancellationToken);
        if (entity is null)
        {
            return NotFound(new { message = $"Opportunité #{id} introuvable." });
        }
        return Ok(entity);
    }

    /// <summary>
    /// Crée une nouvelle opportunité (authentification requise).
    /// </summary>
    [HttpPost]
    [Authorize(Roles = "Admin,Editor")]
    [ProducesResponseType(typeof(OpportunityResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<OpportunityResponseDto>> Create(
        [FromBody] CreateOpportunityDto dto,
        CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        var created = await _service.CreateAsync(dto, cancellationToken);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    /// <summary>
    /// Met à jour une opportunité existante (authentification requise).
    /// </summary>
    [HttpPut("{id:int}")]
    [Authorize(Roles = "Admin,Editor")]
    [ProducesResponseType(typeof(OpportunityResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<OpportunityResponseDto>> Update(
        int id,
        [FromBody] UpdateOpportunityDto dto,
        CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        var updated = await _service.UpdateAsync(id, dto, cancellationToken);
        if (updated is null)
        {
            return NotFound(new { message = $"Opportunité #{id} introuvable." });
        }
        return Ok(updated);
    }

    /// <summary>
    /// Supprime une opportunité (authentification requise).
    /// </summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Admin,Editor")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Delete(int id, CancellationToken cancellationToken)
    {
        var deleted = await _service.DeleteAsync(id, cancellationToken);
        if (!deleted)
        {
            return NotFound(new { message = $"Opportunité #{id} introuvable." });
        }
        return NoContent();
    }
}