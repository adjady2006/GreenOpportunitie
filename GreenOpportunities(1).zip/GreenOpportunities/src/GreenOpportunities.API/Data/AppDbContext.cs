using GreenOpportunities.API.Models;
using Microsoft.EntityFrameworkCore;

namespace GreenOpportunities.API.Data;

/// <summary>
/// Contexte EF Core principal de l'application.
/// Utilise SQLite pour un démarrage simplifié (configurable via appsettings).
/// </summary>
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Opportunity> Opportunities => Set<Opportunity>();
    public DbSet<ApplicationUser> Users => Set<ApplicationUser>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Index pour améliorer les performances de recherche / filtrage
        modelBuilder.Entity<Opportunity>()
            .HasIndex(o => o.Type);

        modelBuilder.Entity<Opportunity>()
            .HasIndex(o => o.Country);

        modelBuilder.Entity<Opportunity>()
            .HasIndex(o => o.Deadline);

        modelBuilder.Entity<Opportunity>()
            .HasIndex(o => o.IsFullyFunded);

        // Contrainte d'unicité sur le nom d'utilisateur et l'email
        modelBuilder.Entity<ApplicationUser>()
            .HasIndex(u => u.Username)
            .IsUnique();

        modelBuilder.Entity<ApplicationUser>()
            .HasIndex(u => u.Email)
            .IsUnique();
    }
}